// ضع هنا رابط Google Apps Script web app بعد نشره (يجب أن يكون Deploy as Web App - Anyone, even anonymous)
const GOOGLE_SCRIPT_URL = ""; // مثال: "https://script.google.com/macros/s/AKfycbx.../exec"
