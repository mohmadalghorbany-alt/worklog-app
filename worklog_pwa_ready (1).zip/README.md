README - Worklog PWA (Arabic)
================================

هذا المشروع جاهز للنشر كـ PWA. يحتوي على نموذج عربي يرسل البيانات إلى Google Sheets عبر Google Apps Script.

الخطوات النهائية (سريعة):

1) افتح جدول Google Sheets الذي أرسلته.
2) من القائمة: Extensions -> Apps Script
3) الصق الكود التالي في المحرّر (File > New > Script) وضع اسمًا مثل 'WorklogWebApp':

----- BEGIN Google Apps Script -----
function doPost(e){
  try{
    var data = JSON.parse(e.postData.contents);
    var ss = SpreadsheetApp.openByUrl("GOOGLE_SHEET_URL");
    var sheet = ss.getSheets()[0]; // أول ورقة
    sheet.appendRow([
      new Date(),
      data.timestamp || "",
      data.date || "",
      data.student || "",
      data.attendance || "",
      data.sessions || "",
      data.notes || ""
    ]);
    return ContentService.createTextOutput(JSON.stringify({result:'success'})).setMimeType(ContentService.MimeType.JSON);
  }catch(err){
    return ContentService.createTextOutput(JSON.stringify({result:'error', error: err.message})).setMimeType(ContentService.MimeType.JSON);
  }
}
----- END Google Apps Script -----

4) غيّر النص "GOOGLE_SHEET_URL" في الكود أعلاه وضع رابط الجدول الكامل:
   مثال: "https://docs.google.com/spreadsheets/d/1zbqy8R3_4S5de-BiKgy4Se_0qR0JGR0N/edit"

5) احفظ المشروع ثم: Deploy -> New deployment
   - اختر "Web app"
   - Execute as: "Me"
   - Who has access: "Anyone" أو "Anyone, even anonymous"
   - اضغط Deploy ثم انسخ رابط الـ Web app (سيبدأ بـ https://script.google.com/macros/s/...)

6) افتح ملف config.js وضع رابط الـ Web app داخل GOOGLE_SCRIPT_URL.

7) افتح index.html محليًا أو ارفع المجلد public إلى استضافة (Vercel / Netlify).
   - أسهل: يمكنك رفع مجلد 'public' إلى Netlify (سحب وإفلات) أو نشر كامل المشروع على Vercel.

ملاحظات مهمة:
- تأكد أن جدول Google Sheets يسمح بالتعديل (Anyone with link -> Editor) أو أن Apps Script لديه صلاحية الوصول (Execute as: Me).
- إذا أردت حماية الإدخالات، يمكننا إضافة مفتاح سري بسيط داخل Apps Script ومقارنته قبل السماح بالإضافة.

نهاية README
